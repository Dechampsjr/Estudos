<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/styleh.css" type="text/css" rel="stylesheet"/>
    <title>TELA PRINCIPAL</title>
</head>
<body>
    <h1>Meus Cursos</h1>
   
        <div class="box">
            <a href="login.php">Login</a>
            <a href="Form.php">Cadastre-se</a>
        </div>


</body>
</html>