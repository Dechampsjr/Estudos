<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/stylelo.css" type="text/css" rel="stylesheet"/>
    <title>Tela Login</title>
</head>
<body>
    <div class="tlogin">
        <h1>Login</h1>
        <form action="testeLogin.php" method="POST">
        <input type="text" placeholder="Email" name="email">
       
        <input type="password" placeholder="Senha" name="senha">
        <br>
        <br>
        <input class="inputSubmit" type="submit" name="submit" value="Enviar">
        <div class="btn-sair">
            <a href="home.php" class="btn btn-danger me-5">Sair</a>
                 </div>
       

        </form>

    </div>
    
</body>
</html>