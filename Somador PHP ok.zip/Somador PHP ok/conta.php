<html>
<head>
	<title> Minha Página PHP </title>
<meta charset="utf-8"/>	
<link rel="stylesheet" type="text/css" href="estilo.css" />
<?php
	$n1 = $_POST["n1"];
	$n2 = $_POST["n2"];
?>
</head>

<body>
	<div id="menu">
	<h1><center> PHP </center></h1>
<div id="form">
	<form method="post" id="fcalc" action="conta.php">
	<fieldset> <legend>Resultado</legend>
		<p><label > A soma é:<?php echo ($n1 + $n2);?></label></p>
		<p><label >A subtração é:<?php echo ($n1 - $n2);?></label></p>
		<p><label >A multiplicação é:<?php echo ($n1 * $n2);?></label></p>
		<p><label >A divisão é:<?php echo ($n1 / $n2);?></label></p>
		
	</fieldset>
	</form>
</div>

</div>

</body>

</html>