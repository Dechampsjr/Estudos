<!DOCTYPE html>

<html>

    <head>

        <title>Numero e seu dobro</title>

        <style>

            form { width: 200px; height: auto; margin: 0 auto; }

            label, input { width: 100%; height: auto; display: block; float:left; margin: 5px 0; }

             

        </style>

    </head>

     

    <body>

    <?php

    


      

     if(isset($_POST['numero'])){ 

         
        

        $numero = $_POST['numero'];

         

      

        $resultado = (2*$numero);

         

        
        echo "O dobro de " . $numero . " e " . $resultado;

     }

    ?>

     

    <form action="#" method="post">

         

        <fieldset>

         

            <label>Digite um numero:</label>

            <input type="text" name="numero" value="" />

             

            <input type="submit" value="Enviar" />



        </fieldset>

         

  </form>

    </body>

</html>
